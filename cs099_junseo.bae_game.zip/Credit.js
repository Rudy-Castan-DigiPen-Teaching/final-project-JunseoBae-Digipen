// Name: Junseo Bae
// Assignment Name: Final Project Prototype
// Course Number: CS099
// Term & Year: Spring 2020s

/*class Credit{
    constructor(){
        this.mainmenu = new Button(width/2, height - 50, "Main Menu");
    }

    Update(){
        if(this.mainmenu.DidClickButton()){
            console.log("Main Menu!");
            CurrentScene = MAIN_MENU;
        }
    }

    Draw(){
        DrawTitle("Credits");

        text("Made by Rudy Castan", width/2, height/2);

        this.mainmenu.DrawButton();
    }
}*/